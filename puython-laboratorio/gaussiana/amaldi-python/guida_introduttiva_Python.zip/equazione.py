#risolvere l'equazione 10 * x = 5
a = 10
b = 5
print(f"La soluzione dell'equazione è {b/a}") #esempio di f-string