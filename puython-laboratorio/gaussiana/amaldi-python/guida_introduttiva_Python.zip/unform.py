import numpy as np

x = np.random.uniform(-1,1,4)
print(x)


