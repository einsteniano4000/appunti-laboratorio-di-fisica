import numpy as np

array = np.linspace(1, 2, 5)
print(array)




