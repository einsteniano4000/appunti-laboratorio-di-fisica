T = 293
r = 0.011767810
print(f"La sfera a temperatura {T:.2f} K ha un raggio pari a: {r:.4f} m")
    
    
    
    
    