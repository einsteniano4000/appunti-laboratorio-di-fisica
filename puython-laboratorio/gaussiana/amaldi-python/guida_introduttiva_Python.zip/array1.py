import numpy as np

array = np.array([1.2, 1.5, 2.1, 2.8, 2.0, 1.0, -1.0, -2.3])
print(array[0])
print(array[-8])
print(array[7])
print(array[-1])


