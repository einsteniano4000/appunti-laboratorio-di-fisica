import numpy as np

array = np.linspace(0, 5, 6)
print(np.sqrt(array))

alfa = np.pi/2
print(np.sin(alfa))


